package servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import model.DatabaseConnection;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/returnbook")
public class ReturnBookServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int bookId = Integer.parseInt(request.getParameter("book_id"));
        String registrationNumber = request.getParameter("registration_number");

        try (Connection conn = DatabaseConnection.getConnection()) {
            // First, check if the book with the registration number exists
            String checkSql = "SELECT return_date FROM issued_books WHERE book_id = ? AND registration_number = ?";
            PreparedStatement checkStmt = conn.prepareStatement(checkSql);
            checkStmt.setInt(1, bookId);
            checkStmt.setString(2, registrationNumber);

            ResultSet rs = checkStmt.executeQuery();

            if (rs.next()) {
                // Book is found
                if (rs.getDate("return_date") != null) {
                    // Already returned
                    request.setAttribute("message", "⚠️ Book already returned.");
                } else {
                    // Not yet returned, update it
                    String updateSql = "UPDATE issued_books SET return_date = CURRENT_DATE() WHERE book_id = ? AND registration_number = ?";
                    PreparedStatement updateStmt = conn.prepareStatement(updateSql);
                    updateStmt.setInt(1, bookId);
                    updateStmt.setString(2, registrationNumber);
                    updateStmt.executeUpdate();

                    request.setAttribute("message", "✅ Returned Successfully!");
                }
            } else {
                // Book not found
                request.setAttribute("message", "❌ Book not found.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("message", "⚠️ Error occurred during returning the book.");
        }
        
        // Forward back to returnbook.jsp with the message
        request.getRequestDispatcher("returnbook.jsp").forward(request, response);
    }
}
