package servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import model.DatabaseConnection;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/issuebook")
public class IssueBookServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            int bookId = Integer.parseInt(request.getParameter("book_id"));
            String bookName = request.getParameter("book_name");
            String issuedTo = request.getParameter("issued_to");
            String registrationNumber = request.getParameter("registration_number");
            String issuedDateStr = request.getParameter("issued_date");
            String returnDateStr = request.getParameter("return_date");

            Date issuedDate = Date.valueOf(issuedDateStr);
            Date returnDate = (returnDateStr == null || returnDateStr.isEmpty()) ? null : Date.valueOf(returnDateStr);

            try (Connection conn = DatabaseConnection.getConnection()) {
                String sql = "INSERT INTO issued_books (book_id, book_name, issued_to, registration_number, issued_date, return_date) VALUES (?, ?, ?, ?, ?, ?)";
                PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setInt(1, bookId);
                stmt.setString(2, bookName);
                stmt.setString(3, issuedTo);
                stmt.setString(4, registrationNumber);
                stmt.setDate(5, issuedDate);
                if (returnDate != null) {
                    stmt.setDate(6, returnDate);
                } else {
                    stmt.setNull(6, java.sql.Types.DATE);
                }
                stmt.executeUpdate();
                request.setAttribute("success", "Issued successfully!");
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("success", "❌ Failed to issue book. Please try again.");
        }
        
        RequestDispatcher dispatcher = request.getRequestDispatcher("issuebook.jsp");
        dispatcher.forward(request, response);
    }
}

  
