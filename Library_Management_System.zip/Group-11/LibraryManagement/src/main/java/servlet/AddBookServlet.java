package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.DatabaseConnection;

@WebServlet("/addbook")
public class AddBookServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
        String title = request.getParameter("title");
        String author = request.getParameter("author");
        int quantity = Integer.parseInt(request.getParameter("quantity"));

        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "INSERT INTO books (title, author, quantity) VALUES (?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, title);
            stmt.setString(2, author);
            stmt.setInt(3, quantity);
            int rows = stmt.executeUpdate();

            response.setContentType("text/html");
            PrintWriter out = response.getWriter();
            
            if (rows > 0) {
                out.println("<html><head><title>Success</title>");
                out.println("<style>");
                out.println("body, html { margin: 0; padding: 0; height: 100%; font-family: Arial, sans-serif; }");
                out.println(".container { display: flex; height: 100vh; }");
                out.println(".left { flex: 1; display: flex; flex-direction: column; justify-content: center; align-items: center; background-color: #222; color: white; font-weight: bold; }");
                out.println(".right { flex: 1; background: url('images/database.jpg') no-repeat center center/cover; }");
                out.println("h2 { font-size: 28px; margin-bottom: 20px; }");
                out.println(".arrow { font-size: 60px; color: #00ff00; animation: moveArrow 2s infinite alternate; }");
                out.println("@keyframes moveArrow { 0% { transform: translateX(0); } 100% { transform: translateX(20px); } }");
                out.println("a { text-decoration: none; color: #00ff00; font-size: 20px; font-weight: bold; margin-top: 20px; }");
                out.println("</style></head><body>");
                
                out.println("<div class='container'>");
                
                // Left side
                out.println("<div class='left'>");
                out.println("<h2>Book '" + title + "' added successfully to database!</h2>");
                out.println("<div class='arrow'>&#8594;</div>"); // Arrow symbol ➡
                out.println("<a href='dashboard.jsp'>Go to Dashboard</a>");
                out.println("</div>");
                
                // Right side
                out.println("<div class='right'></div>");
                
                out.println("</div>");
                out.println("</body></html>");
            } else {
                out.println("<html><head><title>Failure</title>");
                out.println("<style>");
                out.println("body, html { margin: 0; padding: 0; height: 100%; font-family: Arial, sans-serif; }");
                out.println(".container { display: flex; height: 100vh; }");
                out.println(".left { flex: 1; display: flex; flex-direction: column; justify-content: center; align-items: center; background-color: #222; color: white; font-weight: bold; }");
                out.println(".right { flex: 1; background: url('database.jpg') no-repeat center center/cover; }");
                out.println("h2 { font-size: 28px; margin-bottom: 20px; }");
                out.println(".arrow { font-size: 60px; color: red; animation: moveArrow 2s infinite alternate; }");
                out.println("@keyframes moveArrow { 0% { transform: translateX(0); } 100% { transform: translateX(20px); } }");
                out.println("a { text-decoration: none; color: red; font-size: 20px; font-weight: bold; margin-top: 20px; }");
                out.println("</style></head><body>");
                
                out.println("<div class='container'>");
                
                // Left side
                out.println("<div class='left'>");
                out.println("<h2>Failed to add book. Please try again.</h2>");
                out.println("<div class='arrow'>&#8594;</div>"); // Arrow symbol ➡
                out.println("<a href='addbook.jsp'>Back to Add Book</a>");
                out.println("</div>");
                
                // Right side
                out.println("<div class='right'></div>");
                
                out.println("</div>");
                out.println("</body></html>");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            throw new ServletException("Database Error!", e);
        }
    }
}

